# DateTime
 Website displaying the current date and time.


This is a personal website using full-stack development which uses a REST API to tell system date and time by an APIcall.

Technologies used:
Front end Languages:
* HTML
* CSS

Front end Frameworks and Libraries:
* Angular JS
* Bootstrap
       
Backend Framework:
* Node.js
* Express

Database:
* MongoDB


This is a LP3 assignment by Cloud Clounselage.


